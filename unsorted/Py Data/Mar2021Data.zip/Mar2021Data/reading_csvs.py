import os
import csv
import json

resource = "car_sales_table.csv"
path = os.path.join("./","resources",resource)

headers = []
rows = []

csv_to_json = []

with open(path,"rt") as csv_file:
    data = csv.reader(csv_file)
    headers = next(data)
    # print(headers)
    for row in data:
        rows.append(row)
        temp = {}
        for i in range(len(headers)):
            temp[headers[i]] = row[i]
        csv_to_json.append(temp)
        

print(headers)
print(rows)

cost_index = headers.index("CostPrice")
total_revenue = 0

make_index = headers.index("Make")
makes = []

model_index = headers.index("Model")
models_set = set()

mileage_index = headers.index("Mileage")
mileages = []

for row in rows:

    total_revenue += int(row[cost_index])
    if row[make_index] not in makes:
        makes.append(row[make_index])

    models_set.add(row[model_index])

    mileages.append(row[mileage_index])

print(total_revenue)
print(makes)
print(models_set)
mileages.sort()
print(mileages[0])

data = {
    "total_revenue" : total_revenue,
    "makes": makes,
    "models": list(models_set),
    "max_mileage": mileages[0]
}

print(type(data))
json_str = json.dumps(data)
print(type(json_str))
json_dict = json.loads(json_str)
print(json_dict)

car_json_string = json.dumps(csv_to_json)

with open("./resources/car_sales.json","xt") as json_file:
    json_file.write(car_json_string)


