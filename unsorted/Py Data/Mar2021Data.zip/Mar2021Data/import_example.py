import my_module 
from my_module import say_hello as hello
from my_module import *

my_module.say_hello()
greeting = my_module.custom_greeting("Good Morning", "Module")
print(greeting)

print(my_module.x)

hello()
print(get_x())

print(f"You are running {__name__}")