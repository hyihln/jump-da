user = {
    "username": "Hello World",
    "password": "helloWorld1",
    "id": 567,
    1: 100,
    "friend_ids": [123,456],
    "status": {
        "banned": False,
        "active": True
    }
}

print(f"The username is {user['username']}")
print(f"Is the user active? {user['status']['active']}")

user['status']['active'] = False
user['friend_ids'].append(789)

# user['premium_account'] = False
user.update({"premium_account": False})

print(user)

user_id = user.get('id')
print(user_id)

user_keys = user.keys()
user_values = user.values()
user_items = user.items()
print(user_keys)
print(user_values)
print(user_items)

val = user.pop("premium_account")
print(val)
print(user)

new_dictionary = dict.fromkeys(["Hello", "World"],0)
print(new_dictionary)