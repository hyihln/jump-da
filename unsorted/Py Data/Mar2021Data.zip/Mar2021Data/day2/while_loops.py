i = 1
while i < 10:
    j = i * 2
    if i % 4 == 0: break
    print(f"i = {i}")
    i += 1 
else:
    print(f"{i} is greater than 10, loop exiting.")

print(f"End of loop. i = {i}, j = {j}")

fruits = {"apple","kiwi","mango","banana"}

while fruits:
    fruit = fruits.pop()
    if fruit == "apple": continue
    print(fruit)
else: 
    print("Fruit Loop finished")

nums = [1,2,3,4,5]
search = 7
i = 0
while i < len(nums):
    if nums[i] == search:
        print(f"Value found at index {i}")
        break
    i += 1 
else :
    print("Value not found")