letters = ['a','b','c','d','e','f','g','h','i','j','k']

def vowel_filter(letter):
    if letter in ['a','e','i','o','u']:
        return False
    return True

consonants = filter(vowel_filter, letters)
print(list(consonants))

vowels = filter(lambda letter: True if letter in ['a','e','i','o','u'] else False, letters)
print(list(vowels))

upper_letters = map(lambda letter: letter.upper(), letters)
print(list(upper_letters))

list_comp = [letter.upper() for letter in letters if letter not in ['a','e','i','o','u']]
print(list_comp)

gen_ex = (letter.upper() for letter in letters if letter not in ['a','e','i','o','u'])
print(gen_ex)