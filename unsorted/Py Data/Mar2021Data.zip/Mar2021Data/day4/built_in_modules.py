import sys
import math
import random
import time
import datetime
import timeit

print(sys.argv)

print(math.sqrt(25))

print(random.randint(10,20))
print(random.sample(k=3,population=[1,1,2,3,45,"Hello"]))

# print(time.sleep(2))
print(time.time())

print(datetime.datetime.now().minute)
print(datetime.datetime(2019,2,21,12,30))

func = "print('Hello World')"
print(timeit.timeit(stmt=func,number=3))