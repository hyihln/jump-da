def my_gen():
    yield "Hello"
    yield "World"
    yield 42

for val in my_gen():
    print(val)

print(val)

gen1 = my_gen()
print(next(gen1))
print(next(gen1))
print(next(gen1))