import os

print(os.getcwd())

# print(os.rmdir("./newfolder"))

folder_name = "resources"

print(os.path.join("../",folder_name))
