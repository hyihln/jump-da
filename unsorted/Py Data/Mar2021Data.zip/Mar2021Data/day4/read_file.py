import os

path = os.path.join("./","text.txt")

# try:
#     my_file = open(path, "rt")
#     print(my_file.read())
# except FileNotFoundError:
#     print("File Not Found")
# else: 
#     my_file.close()

with open(path, 'rt') as my_file:
    # print(my_file.read(10))
    # print(my_file.readline())
    # print(my_file.readline())
    # print(my_file.readline())
    print(my_file.readlines())

new_file = "newfile.txt"
try:
    open(new_file,"x")
except FileExistsError:
    print("File Already Exists")

with open (new_file, "wt") as my_file:
    my_file.write("Hello Python")

with open (path, "at") as my_file:
    my_file.writelines(["\nThis should be appended", "\nnot overwriting the data"])