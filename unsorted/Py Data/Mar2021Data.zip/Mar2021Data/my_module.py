def say_hello():
    print("Hello World")

def custom_greeting(greeting = "Hello", name = "World"):
    return f"{greeting}, {name}!"



x = 42

def get_x():
    return x

if __name__ == "__main__":
    print(f"You are running {__name__}")
else: 
    print(f"You have imported {__name__}")