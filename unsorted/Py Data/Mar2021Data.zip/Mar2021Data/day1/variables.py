x = "Hello World"
print(x)
x = 42
print(x)

x, y, z = "Car", "Bicycle", "Unicycle"
print(x + y + z)

my_programming_language = "Python"

my_boolean = True
other_boolean = False

print(bool(None))

my_int = 10

my_float = 20.7

my_complex = 3j

print(my_complex * my_complex)
print(my_int + my_float)
print(my_int + my_complex)

print(int(my_float))
print(float(my_int))
print(int(float("42.3")))
print(float("50"))

print("The number is " + str(42))

print(len("Hello World"))

message = "Hello {}, you are {} years old"
new_string = message.format("Python", 31)
print(new_string)

new_string = message.format("Java", 29)
print(new_string)

print(message)
num = 12
print(f"The number is {num}, double the number is {num * 2}")

print(None)
var = "Hello"
print(type(var))

print(isinstance(var, str))

y = 12
print(y)
del y
print(y)


