employee_id = 1
employees = []

while True:
    try: 
        num = int(input("Enter the number of employees: "))
    except:
        print("Please enter number of employees")
    else:
        break

while employee_id <= num:
    full_name = input("Enter employee's first and last name: ").split(" ")
    first_name = full_name[0].lower().capitalize()
    last_name = full_name[1].lower().capitalize()

    while True:
        try:
            age_input = int(input("Enter employee's age: "))
            if age_input < 18:
                raise Exception
        except ValueError:
            print("please enter a number for age")
        except Exception:
            print("Age too low")
        else:
            break
    
    email = f"{first_name.lower()}.{last_name.lower()}{employee_id}@company.com"

    employee = {
        "first_name": first_name,
        "last_name": last_name,
        "age": age_input,
        "email": email
    }
    employees.append(employee)
    employee_id += 1

for employee in employees:
    print(f"""first name: {employee["first_name"]}
    last name: {employee["last_name"]}
    age: {employee["age"]}
    email: {employee["email"]}""")