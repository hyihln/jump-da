# user = {
#     "username": "Hello World",
#     "password": "passWorld!",
#     "id":3
# }

# for key, value in user.items():
#     print(f"Key: {key}, Value: {value}")

# for key in user:
#     print(key)

# print("Greater Than") if 10 > 20 else print("Less Than")

while True:
    try:
        age = int(input("Enter your age"))
        break
    except:
        print("You did not enter an age")
print(age)