# This is a comment
"""
This is a multi line string
    The spacing is preserved
This is how multi line comments are created in Python
"""

print("Hello World") # This is a print statement

print(42)

print([1,2,3])

print(40 + 2)

name = input("Enter your name: ")
print(name)

if name == "Hello World":
    print("You entered " + name)

if name == "42":
            print("You entered 42")
            print("That is a number")
            print("This will not work")