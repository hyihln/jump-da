p1 = input("Player 1, Enter Rock(r), Paper(p), or Scissors(s): ")
if (p1 in ['r', 'p','s']):

    p2 = input("Player 2, Enter Rock(r), Paper(p), or Scissors(s): ")
    if (p2 in ['r', 'p','s']):

        if((p1 == 'r' and p2 == 's') or (p1 == 's' and p2 == "p") or (p1 == 'p' and p2 == "r")):
            print("Player 1 Wins!")
        elif ((p2 == 'r' and p1 == 's') or (p2 == 's' and p1 == "p") or (p2 == 'p' and p1 == "r")):
            print("Player 2 Wins!")
        else:
            print("It's a Tie!")
    
    else :
        print("Please try again")
else: 
    print("Please Try again")