fruits = ["apple", "kiwi", "mango", "banana", "avocado"]
drinks = ["coffee", "tea","milkshake","Capri Sun","smoothie"]

for fruit in fruits:
    print(fruit)
else:
    print("loop finished")
print(f"last fruit: {fruit}")


for i in range(5):
    print(f"{i}: {fruits[i]}, {drinks[i]}")

my_range = range(10)
short_range = range(3,10)
fast_range = range(1,10,2)

for i in fast_range:
    pass
print("empty loop")