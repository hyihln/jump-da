num = int(input("Enter a Number: "))

if num > 10:
    print("Your number is greater than 10")
    if num % 2 == 0: print("Your number is also even")
    else: print("Your number is also odd")
elif num > 5: print("Your number is between 5 and 10")
else: print("Your number is less than 5")

message = "Your number is 42" if num == 42 else "Your number is not 42"
print(message)